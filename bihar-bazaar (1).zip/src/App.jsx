import React, { useState } from "react";

export default function App() {
  const sampleProducts = [
    {
      id: 1,
      name: "Thekua (ठेकुआ)",
      desc: "मक्खनदार और गरमा गरम पारंपरिक बिस्कुट — घर जैसा स्वाद.",
      price: 150,
      unit: "250g",
      img: "https://source.unsplash.com/800x600/?thekua,biscuit",
    },
    {
      id: 2,
      name: "Khasta (खस्ता)",
      desc: "क्रिस्पी और मसालेदार — त्योहारों की शान.",
      price: 120,
      unit: "200g",
      img: "https://source.unsplash.com/800x600/?khasta,snack",
    },
    {
      id: 3,
      name: "Litti Chokha Pack",
      desc: "घरेलू तरीके से बनी स्वादिष्ट लिट्टी-चोखा (frozen/ready-to-eat).",
      price: 320,
      unit: "4 पीस",
      img: "https://source.unsplash.com/800x600/?litti,chokha,food",
    },
    {
      id: 4,
      name: "Laung-Lata (लौंग-लता) मिष्ठान",
      desc: "मिठास भरा पारंपरिक पटना स्टाइल मिष्ठान.",
      price: 220,
      unit: "300g",
      img: "https://source.unsplash.com/800x600/?indian-sweets",
    },
  ];

  const [products] = useState(sampleProducts);
  const [cart, setCart] = useState([]);

  function addToCart(product) {
    setCart((prev) => {
      const found = prev.find((p) => p.id === product.id);
      if (found) {
        return prev.map((p) =>
          p.id === product.id ? { ...p, qty: p.qty + 1 } : p
        );
      }
      return [...prev, { ...product, qty: 1 }];
    });
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4 flex justify-between">
        <h1 className="text-2xl font-bold text-rose-600">BiharBazaar</h1>
        <div>Cart: {cart.reduce((s, p) => s + p.qty, 0)}</div>
      </header>
      <main className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((p) => (
          <div key={p.id} className="bg-white rounded-2xl shadow p-4">
            <img src={p.img} alt={p.name} className="rounded-lg h-40 w-full object-cover" />
            <h3 className="mt-2 text-lg font-semibold">{p.name}</h3>
            <p className="text-sm text-gray-600">{p.desc}</p>
            <div className="mt-2 flex justify-between items-center">
              <div className="font-bold">₹{p.price}</div>
              <button
                onClick={() => addToCart(p)}
                className="px-3 py-1 bg-rose-500 text-white rounded-md"
              >
                Add
              </button>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}
